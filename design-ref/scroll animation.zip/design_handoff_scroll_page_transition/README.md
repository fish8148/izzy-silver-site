# Handoff: Scroll page transition — "Roll from the seam" (11a)

## Overview
This feature lets visitors to the Izzy Silver site move between pages by scrolling, as an alternative to opening the edge menu by hand. When you scroll past the end of a page, the next page builds up as a "pull":

1. The **seam** (the glowing edge indicator already on the site) stretches.
2. The **edge menu** opens out of the seam, starting from the middle label.
3. The menu list **rolls** up one slot, so the next page's label moves into the "current" slot and turns blue.
4. If the pull reaches 100%, the page swaps behind the menu and the menu tucks away. If the user stops early, the pull springs back to 0.

Scrolling up past the top of a page goes to the previous page the same way, with the list rolling the other direction.

The prototype shows **photos → my things** and back. In production it should work for every adjacent pair in the page order.

## About the design files
The files in `prototype/` are **HTML design references**, not production code. They use a custom prototyping runtime (`support.js`, `*.dc.html`) that should not be shipped. Rebuild the behavior inside the existing site code, next to the edge menu that is already there (`src/ui/edge-menu.js`, `src/styles/edge-menu.css`). Reuse its DOM, label styling, shade gradient and seam rather than duplicating them.

To view the prototype, open `prototype/Scroll Between Pages.dc.html` in a browser. 11a is at the top. You can scroll over the board, drag it up and down, or click it and use the arrow keys.

## Fidelity
**High fidelity.** Colors, type, timings and easing are final. The "my things" page in the prototype is a stand-in (grey tiles). Use the real page.

---

## Page order
`homepage → about me → photos → my things → say hi`. This matches the edge menu's label order, top to bottom.
- Scrolling down past the bottom goes to the **next** page. Scrolling up past the top goes to the **previous** page.
- Nothing happens before the first page or after the last one: no pull, and the page doesn't move.

## Recommended values
These are the values Izzy settled on. Wherever they differ from the prototype defaults, use these. Keep them all in one config object so they're easy to tune.

| key | value | meaning |
|---|---|---|
| `distance` | 600 | Pixels of wheel delta past the edge that make a full pull (0 → 1). |
| `springBack` | 0.80 | When the user stops early, multiply the pull by this every frame until it is under 0.005. |
| `releaseDelay` | 200 ms | How long after the last wheel event before the spring-back starts. |
| `cooldown` | 700 ms | After a page change, ignore wheel input for this long so trackpad inertia doesn't trigger a second change. |
| `seamStart` | 0.35 | The part of the pull where only the seam stretches. |
| `menuOpen` | 0.5 | Fraction of the remaining pull (after `seamStart`) over which the menu opens. |
| `rollLag` | 0.3 | Fraction of the remaining pull to wait before the roll begins. |
| `seamGrow` | 440 px | Extra height the seam gains. Its resting height is 200 px. |
| `seamWidth` | 4 px | Seam width at full stretch. Its resting width is 2 px. |
| `stagger` | 0.22 | Delay per label as the menu opens outward from the middle label. |
| `slide` | 40 px | How far each label slides in from the right as it appears. |
| `shade` | 1 | Maximum opacity of the menu's dark shade gradient. |
| `activeScale` | 0.12 | How much the label in the current slot grows (1 + 0.12). |
| `rows` | 2.6 | Labels further than this many slots from the current slot fade to 0. |
| `tilt` | 1 | Multiplier on each label's small resting rotation. |
| `marker` | **false** | Small blue bar beside the current slot. Izzy turned it off. |
| `duration` | 1000 ms | Length of the page-change animation once the pull is complete. |
| `hold` | 0.55 | Fraction of `duration` the menu stays fully open; the page crossfade also happens within it. |
| `pageShift` | **115 px** | Vertical travel of the outgoing and incoming pages during the swap. |

## Easing helpers
```js
const clamp01 = x => Math.max(0, Math.min(1, x));
const sm = x => { x = clamp01(x); return x * x * (3 - 2 * x); };   // smoothstep
```

## Input → pull (state machine)
State: `page`, `scroll` (the page's own scroll position), `pull` (0..1), `going` (bool), `t` (0..1 during the page change).

On each `wheel` event (`passive: false`; normalize `deltaMode === 1` lines by ×33):
```
if going or now < cooldownUntil: preventDefault, return
atBottom = scrollTop >= scrollHeight - clientHeight - 1
atTop    = scrollTop <= 0
dir = sign(deltaY)            // +1 = down/next, -1 = up/previous
hasTarget = (dir>0 && nextPage) || (dir<0 && prevPage)

if hasTarget and ((dir>0 && atBottom) or (dir<0 && atTop)):
    preventDefault
    pull = min(1, pull + |deltaY| / distance); pullDir = dir
else if pull > 0:                         // reversing direction eats the pull first
    preventDefault
    pull = max(0, pull - |deltaY| / distance)
else:
    let the page scroll normally

restart releaseDelay timer → spring back (pull *= springBack per rAF)
if pull >= 1 → commit()
```
- While `pull > 0`, stop the page itself from scrolling.
- Keyboard: ArrowDown/ArrowUp/PageDown/PageUp/Space at the page's edge should feed the same function, at roughly 80 / 300 px per press.
- Touch: an equivalent vertical swipe at the edge is optional. If you add it, move about 1.5× the finger's distance.
- `pullDir` sets the target: the **to** page is next if +1, previous if −1.

## Rendering from `pull` (while not committing)
Let `p = pull`, `S = seamStart`, `ph = 1 − S`.
```
m = sm((p − S) / (ph · menuOpen))                     // menu openness 0..1
c = sm((p − S − ph·rollLag) / (ph · (1 − rollLag)))   // roll progress 0..1
k = min(1, p / S)                                     // seam stretch 0..1
```
**Seam (on the right edge; it is the same element the site already uses):**
- `height = 200 + k·seamGrow`, vertically centered on the viewport.
- `width = 2 + k·(seamWidth − 2)`, `right: 6px`.
- `opacity = (0.28 + 0.72·k) · (1 − m)`. It fades out as the menu takes over.
- Pause the seam's idle "breathe" animation whenever `pull > 0`.

**Shade:** set the existing menu shade gradient's `opacity` to `m · shade`.

**Menu labels:** these are the existing edge-menu labels (52 px, right-aligned 72 px from the right edge, evenly spaced). Let `gap` be the distance between two label centers, `slot` the vertical center of the **current page's** label in its normal resting position, `curIdx` the current page's index, and `slotIdx` the index whose resting position is `slot`.
```
rollOffset = −(curIdx − slotIdx)·gap − pullDir·c·gap    // in practice the first term is 0 if you lay out around the current page
for each label i:
    top   = restingTop(i) + rollOffset
    d     = |top − slot| / gap                  // distance from the current slot, in slots
    mk    = sm(m·(1 + 2·stagger) − |i − curIdx|·stagger)   // opens outward from the current label
    opacity   = mk · sm(1 − d / rows)
    translateX = (1 − mk) · slide
    color = mix(#ffffff → #6fb3e0, sm(1 − d))   // blue only at the current slot
    scale = 1 + activeScale · sm(1 − d)          // transform-origin: right center
    rotate = existing per-label rotation × tilt
```
- The labels **roll through a fixed slot** rather than the highlight jumping, so when `c = 1` the to-page's label sits exactly where the current label was.
- The prototype measures distance from the middle label (index 2). Use the current page's index so the effect is centered on the current page's label for every page.
- Do not let the labels catch the pointer during the scroll gesture (`pointer-events: none`) unless the menu is fully open.

**Pages:** while pulling, move the current page by `translateY(−pullDir · p · 20px)` as a small rubber-band nudge.

## Commit (page change) animation
When `pull` reaches 1, set `going = true` and run `t` from 0 to 1 over `duration` ms (rAF, linear `t`).
```
m  = t < hold ? 1 : 1 − sm((t − hold)/(1 − hold))   // menu holds open, then tucks away
c  = 1                                              // roll stays complete
sw = sm(t / hold)                                   // page swap progress
outgoing: opacity 1 − sw,  translateY(−pullDir·(20 + sw·pageShift))
incoming: opacity sw,      translateY( pullDir·pageShift·(1 − sw)),  stacked above outgoing
shade = m · shade
seam opacity = 0 while the menu is visible
```
When `t = 1`:
- Make the to-page current and update the URL/route the same way a menu click does.
- Set the new page's scroll position: **top (0)** if you moved forward, **bottom** if you moved back.
- Reset `pull = 0`, `going = false`, and start `cooldown`.
- The new page's label is now the current one, so set the menu's resting layout so it isn't moved by the roll. Nothing should visibly jump.

## Interaction with the existing edge menu
- If the user opens the edge menu by touching the screen edge, cancel any pull (set it to 0) and ignore scroll-to-pull until the menu closes.
- During `going`, ignore the edge-hover open and clicks on the menu.
- Accessibility: if `prefers-reduced-motion: reduce` is set, skip the roll and slides. When the pull completes, cross-fade the pages over 200 ms.

## Design tokens
- Background `#000000`
- Menu label `#ffffff`. Current page label `#6fb3e0`.
- Shade: `linear-gradient(to left, rgba(14,14,14,.97) 0%, rgba(14,14,14,.95) 34%, rgba(14,14,14,.8) 52%, rgba(14,14,14,.42) 72%, rgba(14,14,14,.12) 88%, rgba(14,14,14,0) 100%)`, covering 72% of the width from the right. This is the existing shade.
- Seam:
  - Background: `linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,.95) 50%, rgba(255,255,255,0))`
  - `box-shadow: 0 0 14px rgba(255,255,255,.35)`
  - `border-radius: 4px`
  - Idle breathe: opacity .55 → 1 → .55 over 4.5 s, ease-in-out, infinite.
- Label shadow: `drop-shadow(0 0 14px rgba(0,0,0,.7))`
- Type: Inter (the site's `--font`), 400, 52 px menu labels and 34 px page header. Line-height 1.1, letter-spacing .01em.

## State summary
`page`, `scroll` (native), `pull`, `pullDir`, `going`, `t`, `cooldownUntil`, the release timer, and the rAF id. Drive every visual from these values on each frame. Use CSS transitions only for the edge menu's existing hover open, not for anything controlled by the pull.

## Files
- `prototype/Scroll Between Pages.dc.html`: board 11a with every setting in the Tweaks panel. Earlier explorations (9a–10d) are below it.
- `prototype/Scroll Board.dc.html`: the logic. The `rollseam` code path in `renderVals()` and `onWheel`/`release`/`commit` is the reference implementation.
- `prototype/Edge Board.dc.html`: the seam indicator (8a) on its own.
- `prototype/edge/*.webp`: photos copied from `public/photos`, used only as the demo background.
