# Handoff: Say hi, set like the about page (25a "Intro form")

## Overview
This redesign of the say hi page makes it match **about me (24b)**. The sentence form takes the place of the about intro, and the 3D character stands on the right with **no panel**, just like on about me. The send button and the panel's link row are replaced by **one row of text links with arrows**: `send by email ↗  linkedin ↗  github ↗  resume ↗`. A copy-email line sits under that row. The page fits on one screen.

It builds on the shipped 20b page (`src/pages/say-hi.js`, `.hi-*` in `src/styles/pages.css`). The form logic, sending, validation, sent state and copy behavior **all stay as they are**. Only the layout and the look of the actions change.

## About the design files
`prototype/Say Hi.dc.html` is an HTML design reference, not production code. Open it in a browser, with `support.js` and `assets/` next to it. Build the change in the existing codebase.

## Fidelity
High-fidelity. The figure is `character-poster.webp`, a stand-in for the live model.

## Layout (matches `.about-intro` for 24b)
```css
.hi {
  /* was: grid 1fr 340px, padding 72px 56px 56px */
  display: grid;
  grid-template-columns: minmax(0, 1fr) 360px;
  gap: 64px;
  align-items: center;
  padding: 56px;          /* same side margins as .about (0 56px) plus the intro's 56px top and bottom */
  min-height: 100%;
}
```
- Left: `.hi-main` (unchanged, `justify-content: center`).
- Right: `.hi-side` becomes the character column, styled exactly like 24b's `.about-intro__character`: `position: relative; height: 600px`, no background, no border, no radius, a transparent canvas over `#000`, and a floor glow under his feet. Reuse the same classes or share the CSS:
  ```css
  .hi-floor { position:absolute; left:50%; bottom:-6px; transform:translateX(-50%);
              width:260px; height:40px; border-radius:50%;
              background:radial-gradient(closest-side, rgba(255,255,255,.08), rgba(255,255,255,0));
              pointer-events:none; }
  ```
  Remove the `.hi-stage` panel styling (`#0a0a0a`, `border-radius: 28px`, the inset border).
- **Character framing:** the same as about me, so he's the same size on both pages.

## Form (left): unchanged except type
- `.hi-sentence`: keep it as is, but use `line-height: 1.3` to match the about intro paragraphs (it was 1.5).
- `.hi-message` and `.hi-input`: unchanged. In the prototype the textarea is 150px tall; keep whatever production has if it's close.
- The form keeps `gap: 28px`. Put `margin-top: 8px` on the actions row, like `.about-intro__links`.

## Actions row: the main change
Markup, inside `.hi-form` after the textarea:
```
<div class="hi-actions">
  <div class="hi-links-row">
    <button type="submit" class="hi-send">send by email ↗</button>   (label: "send ↗" when formEndpoint is set, as now)
    <a class="hi-link" href="linkedin" target="_blank" rel="noopener noreferrer">linkedin ↗</a>
    <a class="hi-link" href="github"   …>github ↗</a>
    <a class="hi-link" href="resume"   …>resume ↗</a>          (the same resume URL and version query as about.js)
  </div>
  <p class="hi-alt">or copy <button class="hi-copy">isilver@uwaterloo.ca</button> <span class="hi-copy-label">click to copy</span></p>
</div>
<p class="hi-error" …></p>
```
- The links move out of `.hi-side` and into this row. Skip any link with an empty `href`, as now. GitHub is empty in `contact.js` today, so add the URL there. Resume isn't in `contact.js`; import `about.resume` and reuse `resumeLink()`'s URL logic from `about.js` (move it into a small shared helper).

```css
.hi-actions { display:flex; flex-direction:column; gap:14px; margin-top:8px; }
.hi-links-row { display:flex; flex-wrap:wrap; align-items:baseline; gap:12px 32px; font-size:20px; }

/* send: a text link, not a pill */
.hi-send { padding:0; background:none; border:none; border-radius:0; font:inherit; font-size:20px;
           color:var(--hi-blue); cursor:pointer; transition:color .2s ease; }
.hi-send:not(:disabled):hover { color:var(--hi-blue-hover); background:none; }
.hi-send:disabled { color:var(--hi-muted); background:none; cursor:default; }  /* until a message is typed */

.hi-link { font-size:20px; color:#fff; text-decoration:none; transition:color .2s ease; }
.hi-link:hover, .hi-link:focus-visible { color:var(--hi-blue); }

.hi-alt { font-size:15px; color:var(--hi-muted); }
.hi-copy { color:var(--hi-secondary); }            /* was blue; now quieter, under the row */
.hi-copy:hover { color:var(--hi-blue); }
```
- Send is blue. The three links are white and turn blue on hover. All four are 20px, 32px apart, and each ends in ↗.
- Disabled send is grey `#5a5a5a` text, with no background.
- `.hi-error` stays under the actions. Change its `margin-top` to `-14px` so it sits tight under the row.

## Sent state
Unchanged. It replaces the form in the left column, and the character stays.

## Under 960px
The same treatment as about me: one column, the character above at `height: min(60vh, 520px)`, then the form. The links row wraps.

## Tokens (existing)
`#000` page · `#fff` sentence 34px/1.3 and links · `#6fb3e0` / `#a9d3ef` blue · `#8f8f8f` email · `#5a5a5a` muted and disabled · `#3a3a3a` underline · `#121212` textarea · Inter 400.

## Files
- `prototype/Say Hi.dc.html`: the 25a frame.
- `prototype/assets/character-poster.webp`: the stand-in figure.
- `prototype/support.js`: the runtime needed to open the prototype.
