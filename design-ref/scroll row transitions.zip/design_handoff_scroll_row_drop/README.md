# Handoff: Scroll page transition — "Drop" row (16a)

## Overview
This lets visitors move between pages by scrolling past the end of a page.

1. When the visitor scrolls past the bottom of a page, the scroll builds up as a **pull**. The page fades to black, and a full-screen **row of all five page names** appears. The names drop in one at a time, left to right. The current page is blue.
2. If the pull is completed, the **blue hands over** to the next page: its name jumps up and the current one dips.
3. The names **fall away** in the same left-to-right order, the black lifts, and the next page is revealed.
4. If the visitor stops early, the pull springs back and nothing changes.

Scrolling up past the top of a page goes to the **previous** page the same way.

## About the design files
The files in `prototype/` are **HTML design references**, not production code. They use a prototyping runtime (`support.js`, `*.dc.html`) that should not be shipped. Rebuild the behavior inside the existing site code (vanilla JS + CSS, following `src/ui/` and `src/styles/`), next to the edge menu (`src/ui/edge-menu.js`).

To view the prototype, open `prototype/Scroll Row Transition.dc.html` and use board **16a**. You can scroll over it, drag it, or click it and use the arrow keys. Other boards on that page are rejected alternatives. The reference logic is in `prototype/Row Board.dc.html`: the `drop` branch in `renderVals()`, plus `onWheel`, `release` and `commit`.

**This replaces the earlier 11a handoff** (`design_handoff_scroll_page_transition`). Build one or the other, not both. If 11a is already in, swap its rendering for this one and keep its input handling.

## Fidelity
**High fidelity.** Type, colors, layout and motion curves are final. The "my things" page in the prototype is a stand-in.

---

## Page order
`homepage → about me → photos → my things → say hi`, the same order as the edge menu.
- Scrolling down past the bottom goes to the next page. Scrolling up past the top goes to the previous one.
- Nothing happens past the first or last page.

## The row (what the screenshot shows)
- Full-screen black overlay (`#000`), above the page and below the edge menu.
- The five names in one horizontal row, centered both ways. They're separate elements in a flex row with a **44px gap** at 1280px wide; scale with the viewport, e.g. `gap: 3.4vw`.
- Type: Inter 400, **40px** at 1280px wide (`clamp(28px, 3.1vw, 56px)`), line-height 1.2, `white-space: nowrap`.
- **"say hi"**: "say " is upright and "**hi**" is *italic*.
- **Colors:** the current page's name is `#6fb3e0`; the others are `#ffffff`.
- Each name has a small resting tilt and vertical offset, which gives the hand-set look:

| name | rotate | translateY |
|---|---|---|
| homepage | −2.4° | 2px |
| about me | 0° | 0 |
| photos | −1.2° | 1px |
| my things | 0.4° | 0 |
| say hi | −1.6° | −1px |

## Parameters
Keep these in one config object.

| key | value | meaning |
|---|---|---|
| `distance` | 600 | Wheel-delta pixels past the edge for a full pull (0 → 1). |
| `springBack` | 0.82 | If the user stops early, multiply the pull by this every frame until it is under 0.005. |
| `releaseDelay` | 200 ms | Time after the last wheel event before the spring-back starts. |
| `duration` | 1600 ms | Length of the page change once the pull reaches 1. |
| `cooldown` | 700 ms | Ignore input for this long after a change, so trackpad inertia doesn't trigger another one. |
| `dropDist` | 70 px | How far each name falls in and falls away. |
| `stagger` | 0.2 | Per-name delay (see the formulas). |
| `hopUp` | 22 px | How high the incoming name jumps. |
| `dipDown` | 8 px | How far the outgoing name dips. |

## Helpers
```js
const clamp01 = x => Math.max(0, Math.min(1, x));
const sm = x => { x = clamp01(x); return x * x * (3 - 2 * x); };         // smoothstep
const mixBlue = k => `rgb(${255 - 144*k}, ${255 - 76*k}, ${255 - 31*k})`; // #fff → #6fb3e0
```

## Input → pull
This is the same state machine as the earlier 11a handoff.
- `wheel` listener with `passive: false`. Normalize `deltaMode === 1` by ×33.
- If the page is at its bottom and the user scrolls down (or at its top and scrolls up), and there is a page in that direction, call `preventDefault` and do `pull = min(1, pull + |dy| / distance)`.
- If the user reverses while `pull > 0`, reduce the pull first: `pull = max(0, pull − |dy| / distance)`.
- Otherwise let the page scroll normally.
- Restart the `releaseDelay` timer on every event. When it fires, spring back with `pull *= springBack` per animation frame.
- When `pull >= 1`, start the commit animation.
- Keyboard: ArrowUp/ArrowDown/PageUp/PageDown/Space at an edge should feed the same path, at roughly 80 / 300 px per press.
- Ignore all input while the commit animation is running and during the cooldown.

## Animation: while pulling (`p` = pull, 0..1)
```
overlay.opacity = sm(p / 0.5)                       // page fades to black over the first half
pageCurrent.transform = scale(1 − 0.04 · overlay)   // slight push-back
rIn = clamp01((p − 0.15) / 0.45)                    // row entry progress
for each name i (0..4, left → right):
    a = sm(rIn · 1.8 − i · 0.2)                     // staggered drop-in
    translateY = restY[i] − (1 − a) · dropDist      // falls from above
    opacity    = a
    color      = current ? #6fb3e0 : #fff
```

## Animation: commit (`t` = 0..1 over `duration`, linear)
```
sw   = sm((t − 0.08) / 0.30)                       // handover progress
eRaw = clamp01((t − 0.58) / 0.42)                  // exit progress
overlay.opacity = 1 − sm((eRaw − 0.3) / 0.7)       // black lifts during the second half of the exit

for each name i:
    b = sm(eRaw · 1.8 − i · 0.2)                   // staggered fall-away, same order as the entry
    translateY = restY[i] + b · dropDist
    opacity    = 1 − b

    if i == to:   translateY −= hopUp · sin(π · sw);    color = mixBlue(sw)
    if i == from: translateY += dipDown · sin(π · sw);  color = mixBlue(1 − sw)

pageCurrent: hidden from t = 0, already behind the full black overlay
pageNext:    visible from t = 0, scale(0.96 + 0.04 · e) where e = sm((t − 0.58) / 0.42)
```
When `t = 1`:
- Make the next page current and route or update the URL the same way an edge-menu click does.
- Set the new page's scroll position: the **top** if moving forward, the **bottom** if moving back.
- Reset the pull to 0, start the cooldown, and remove or hide the overlay and row.

Each name's transform is `translateY(...) rotate(restRot)`. Apply rotation after the translate so the fall stays vertical.

## Interaction with existing features
- **Edge menu:** if it opens while a pull is in progress, cancel the pull. Ignore edge-hover while committing.
- **Seam indicator:** hide it while the overlay opacity is above 0.
- **Photos page (13a):** this page scrolls inside its chapters container, so that container's top and bottom are the edges, not the window's. Same for any page with its own scroll container.
- **Reduced motion** (`prefers-reduced-motion: reduce`): skip the drops and the hop. Fade the row in, swap the color instantly, and fade out over 200ms.

## Design tokens
- Overlay `#000000`
- Current page `#6fb3e0`. Other names `#ffffff`.
- Type: Inter 400, plus Inter italic 400 for "hi". Load the italic face if the site doesn't already.

## Files
- `prototype/Scroll Row Transition.dc.html`: board 16a.
- `prototype/Row Board.dc.html`: the logic. Use variant `drop`.
- `prototype/edge/*.webp`: placeholder photos.
