# Handoff: About me page — Editorial (14a)

## Overview
This is a redesign of the site's **about me** page. It's a single scrolling page:
1. An **intro**: three short paragraphs set large, a resume link, and a portrait of Izzy.
2. **Three highlights**: studio lab XR, QDoc Inc., and university of waterloo. Each is a section whose name stays pinned on the left while its photos scroll past on the right.
3. A **large resume link** at the end.

## About the design files
The files in `prototype/` are **HTML design references**, not production code. They use a prototyping runtime (`support.js`, `*.dc.html`, `image-slot.js`) that should not be shipped. Rebuild the page in the existing site code (vanilla JS + CSS, following the patterns in `src/ui/` and `src/styles/`).

To view the reference, open `prototype/About Me Page.dc.html` and look at board **14a**. 14b and 14c are rejected alternatives; ignore them.

## Fidelity
**High fidelity.** Layout, type and color are final. The photos, highlight descriptions and resume URL are **placeholders**; see Content.

---

## Layout (reference viewport 1280×720)
Black page (`#000`). Content is inset 56px left and right. The page scrolls in the normal way (window scroll). The site's existing bottom-right page header stays as it is on other pages, unless Izzy says otherwise.

### 1. Intro (at least one viewport tall)
- `min-height: 100vh`, padding `72px 0`, `display: grid; grid-template-columns: minmax(0,1fr) 340px; gap: 64px; align-items: center`.
- **Left column:** a column with a 28px gap.
  - Three paragraphs, each its own block: Inter 400, 34px, line-height 1.3, `#ffffff`, `text-wrap: pretty`.
  - `resume ↗` link: 20px, `#6fb3e0`, no underline, hover `#a9d3ef`. 8px extra top margin.
- **Right column:** portrait, 340×440, `object-fit: cover`, `border-radius: 28px`.

### 2. Highlight sections (×3, in order)
Each section:
- `border-top: 1px solid #262626`, padding `48px 0`.
- `display: grid; grid-template-columns: 360px minmax(0,1fr); gap: 32px`.
- **Left column**, `position: sticky; top: 48px; align-self: start`, a column with an 8px gap:
  - Meta line: number + role, e.g. `01  architectural visualization researcher`. 15px, `#5a5a5a`.
  - Name: 52px, line-height 1.1, letter-spacing .01em, `#ffffff`.
  - Description: 15px, line-height 1.5, `text-wrap: pretty`, 8px top margin. In the real build, use `#8f8f8f` (the prototype shows the placeholder in `#5a5a5a`).
- **Right column:** photo grid, `grid-template-columns: repeat(2, 1fr); grid-auto-rows: 210px; gap: 20px`.
  - Tile spans by index: `[2, 1, 1, 2]` columns, repeating. So the order is a wide photo, two half-width photos, then another wide one.
  - Photos use `object-fit: cover` and `border-radius: 28px`.
  - Any number of photos works. Keep the pattern repeating.

### 3. Closing resume link
- `border-top: 1px solid #262626`, padding `72px 0 96px`.
- `resume ↗` at 52px, line-height 1.1, `#6fb3e0`, hover `#a9d3ef`.

## Content
**Intro** (use exactly as written; the lowercase style is intentional):
> hi, my name is izzy silver. I’m a computer engineering student at university of waterloo.
>
> growing up I had a passion for technology, design, and health.
>
> currently i’m in working at qdoc, a healthcare startup.

(Check with Izzy whether "i’m in working" should be "i’m working".)

**Highlights:**
| # | name | role |
|---|---|---|
| 01 | studio lab XR | architectural visualization researcher |
| 02 | QDoc Inc. | website developer |
| 03 | university of waterloo | student |

- Each highlight needs a description (1–2 sentences) and several photos. Both are still to come from Izzy.
- Ship with an empty description, and hide the element when it's empty.
- Put the content in a data file so it's easy to edit:
```js
// src/data/about.js
export default {
  intro: ['hi, my name is izzy silver. …', '…', '…'],
  portrait: 'about-portrait',
  resume: '/resume.pdf',
  highlights: [
    { slug: 'studio-lab-xr', name: 'studio lab XR', role: 'architectural visualization researcher', description: '', photos: [] },
    { slug: 'qdoc', name: 'QDoc Inc.', role: 'website developer', description: '', photos: [] },
    { slug: 'uwaterloo', name: 'university of waterloo', role: 'student', description: '', photos: [] },
  ],
};
```

**Portrait:** `public/photos/about-portrait.svg` already exists in the repo. Use it until a real photo is supplied.

**Resume:**
- Both links point to the same URL. Use `/resume.pdf` (add the file to `public/`) unless Izzy gives an external URL.
- Open it in a new tab: `target="_blank" rel="noopener"`, with an `aria-label` like "resume (PDF, opens in new tab)".

**Photos:** use the site's responsive image pipeline (`-800.webp`, `-1600.avif`, …) with `srcset`, `loading="lazy"`, and meaningful `alt` text.

## Responsive
- **Under 960px:**
  - Intro: one column. The portrait goes above the text at full width, with a max height of 60vh. Paragraphs use `clamp(24px, 5vw, 34px)`.
  - Highlights: one column. The left column is no longer sticky. Names use `clamp(36px, 7vw, 52px)`.
  - The photo grid stays 2 columns, with `grid-auto-rows` around `clamp(140px, 28vw, 210px)`.
- **Under 560px:** the photo grid becomes 1 column, and every span becomes 1.

## Interaction with existing site features
- Keep the edge menu, the seam indicator and the 11a scroll page transition, if they've been built. The page's "end" for the scroll transition is the bottom of the document.
- Photos have no carousel unless it already exists on this page. If you reuse the photos-page carousel, keep it within one highlight.
- `prefers-reduced-motion`: nothing on this page animates beyond the sticky behavior, so no changes are needed.

## Design tokens
- Background `#000000`
- Text `#ffffff`. Meta `#5a5a5a`. Description `#8f8f8f`. Divider `#262626`.
- Link `#6fb3e0`, hover `#a9d3ef`.
- Type: Inter (`--font`) 400. Sizes: 52px names and closing link, 34px intro, 20px intro link, 15px meta and description.
- Photo and portrait radius 28px. Grid gap 20px.

## Files
- `prototype/About Me Page.dc.html`: board 14a is the reference.
